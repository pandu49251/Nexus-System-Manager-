"""
nexus_doctor.checks
===================

Diagnostic check modules.

Each module registers itself with :func:`nexus_doctor.core.engine.register` at
import time.  Importing this package therefore populates the engine's check
registry -- which is exactly what :meth:`Engine.load_checks` relies on.

Contract for a check module
---------------------------
* It must be **read-only**.  A check observes and reports; it never changes
  anything.  (``tests/test_readonly.py`` enforces this by running every check
  with filesystem write-protection enabled.)
* All OS access goes through :mod:`nexus_doctor.core.executil`.
* It returns a :class:`CheckResult` containing zero or more :class:`Finding`
  objects, each carrying the evidence that justifies it.
* It must never raise: raise-proofing is handled by the engine, but a check
  should degrade gracefully and say so when data is unavailable.
"""

from ..core.engine import CHECKS  # noqa: F401  (re-exported for convenience)

__all__ = ["CHECKS"]

# Import order below is deliberate: it groups related probes and lets the
# engine's priority field control the actual execution order.
from . import (  # noqa: F401,E402
    common,
    memory,
    storage_health,
    storage_space,
    cpu_thermal,
    battery,
    graphics,
    keyboard_input,
    kernel_drivers,
    services_startup,
    software_errors,
    system_config,
    filesystem_perf,
)

CHECK_IDS = [c.id for c in CHECKS]
