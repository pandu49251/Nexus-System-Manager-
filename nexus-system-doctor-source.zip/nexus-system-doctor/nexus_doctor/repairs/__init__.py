"""
nexus_doctor.repairs
====================

Repair actions.

A repair is only ever offered when a finding asks for it (``Finding.repair_ids``)
or when it independently confirms that it applies.  Every repair implements
``available``, ``steps``, ``apply``, ``verify`` and ``rollback``; the engine in
:mod:`nexus_doctor.core.repairer` refuses to report success unless ``verify``
passes after ``apply``.

Importing this package registers every repair with the engine.
"""

from ..core.repairer import all_repairs, get_repair  # noqa: F401

from . import (  # noqa: F401
    memory_storage,
    cleanup_services,
    desktop_input,
)

__all__ = ["all_repairs", "get_repair"]
