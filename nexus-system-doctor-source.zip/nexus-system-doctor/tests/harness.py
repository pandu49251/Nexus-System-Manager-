"""
Test harness: points the application at a synthetic machine.

The engine reads its environment once at import time, so this module must be
imported (and :func:`use_fixture` / :func:`use_real_machine` called) before any
other part of the application is imported.
"""

from __future__ import annotations

import os
import shutil
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

FIXTURE_DIR = os.path.join(ROOT, "tests", "fixtures", "lenovo_s145")
FIXTURE_ROOTFS = os.path.join(FIXTURE_DIR, "rootfs")

_TMPDIRS: list = []


def _reset_caches() -> None:
    """Clear every module-level cache so a new machine state takes effect."""
    from nexus_doctor.core import executil as ex
    ex._FIXTURE_CACHE = None
    ex._FIXTURE_TOOLS = None
    ex._TICKERS.clear()
    ex._TICK_COUNT.clear()
    ex._RESPONSE_IDX.clear()
    ex._STATVFS_FIXTURES.clear()
    ex._DIR_SIZE_FIXTURES.clear()
    ex._TOOL_CACHE.clear()
    ex._PHASE = 0
    from nexus_doctor.core import privileges
    privileges._X_ENV_CACHE = None


def set_mode(sysroot: str | None = None, fixtures: str | None = None,
             sandbox: str | None = None, test_root: bool = False,
             gui: bool = True) -> None:
    """Reconfigure where the application reads from, for the current process."""
    env = os.environ
    for var, value in (("NEXUS_SYSROOT", sysroot), ("NEXUS_FIXTURES", fixtures),
                       ("NEXUS_SANDBOX", sandbox),
                       ("NEXUS_TEST_ROOT", "1" if test_root else None)):
        if value:
            env[var] = value
        else:
            env.pop(var, None)
    if gui:
        env.setdefault("DISPLAY", ":0")
        env.setdefault("XAUTHORITY", "/home/user/.Xauthority")
        env.setdefault("XDG_CURRENT_DESKTOP", "XFCE")
    else:
        env.pop("DISPLAY", None)
        env.pop("XAUTHORITY", None)

    from nexus_doctor.core import executil as ex
    ex.SYSROOT = sysroot or ""
    ex.FIXTURES = fixtures or ""
    ex.SANDBOX = sandbox or ""
    _reset_caches()


def make_scratch_rootfs() -> str:
    """A writable copy of the fixture machine's filesystem tree."""
    path = tempfile.mkdtemp(prefix="nexus-test-rootfs-")
    _TMPDIRS.append(path)
    shutil.copytree(FIXTURE_ROOTFS, path, dirs_exist_ok=True, symlinks=True)
    return path


def make_scratch_dir() -> str:
    path = tempfile.mkdtemp(prefix="nexus-test-")
    _TMPDIRS.append(path)
    return path


def use_fixture(writable: bool = True, root: bool = False, gui: bool = True) -> str:
    """Point the app at the synthetic IdeaPad. Returns the rootfs path."""
    rootfs = make_scratch_rootfs() if writable else FIXTURE_ROOTFS
    set_mode(sysroot=rootfs, fixtures=FIXTURE_DIR,
             sandbox=rootfs if writable else None, test_root=root, gui=gui)
    return rootfs


def use_real_machine(sandbox: str | None = None) -> None:
    """Point the app at the machine running the tests (read-only mode)."""
    set_mode(sysroot=None, fixtures=None,
             sandbox=sandbox or make_scratch_dir(), test_root=False, gui=False)


def cleanup() -> None:
    for path in _TMPDIRS:
        shutil.rmtree(path, ignore_errors=True)
    _TMPDIRS.clear()


def manifest(root: str) -> dict:
    """{relative path: (size, mtime)} for every file under *root*."""
    out = {}
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            full = os.path.join(dirpath, name)
            try:
                st = os.stat(full)
            except OSError:
                continue
            out[os.path.relpath(full, root)] = (st.st_size, int(st.st_mtime))
    return out


def manifest_diff(before: dict, after: dict) -> dict:
    """Describe how the filesystem tree changed between two manifests."""
    changes = {}
    for path in set(before) | set(after):
        if path not in before:
            changes[path] = "added"
        elif path not in after:
            changes[path] = "removed"
        elif before[path] != after[path]:
            changes[path] = "modified"
    return changes


def fixture_commands() -> dict:
    import json
    with open(os.path.join(FIXTURE_DIR, "commands.json"), encoding="utf-8") as fh:
        return json.load(fh)
