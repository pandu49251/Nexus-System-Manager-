Synthetic reference machine: Lenovo IdeaPad S145-14AST (81ST)
============================================================

CPU      : AMD A6-9225 RADEON R4, 5 COMPUTE CORES 2C+3G
RAM      : 3.7 GiB, no swap
Disk     : ST1000LM035-1RK172 (1 TB, 5400 rpm, mechanical)
GPU      : AMD Stoney [Radeon R4 Graphics], amdgpu driver
Kernel   : 5.15.0-91-generic
Desktop  : Linux Mint 21.3 Xfce

This is NOT a snapshot of a real machine. It is a hand-built fixture that
reproduces the exact sysfs/proc layout and tool output of the target
laptop so that every diagnostic code path can be tested offline and
deterministically. It deliberately includes several real faults: bad
sectors, ATA errors, OOM kills, a worn battery, thermal throttling, a
stuck modifier key, the slow X11 key-repeat default, a running file
indexer, failed services and a nearly full disk.

Regenerate with:  python3 tools/make_fixture.py
